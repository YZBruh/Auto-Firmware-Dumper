#!/usr/bin/bash
#Samsung stock yazılım ayıklayıcı
#By @YZBruh
#Logcat temizliği
clear
#Değer atamaları (ön)
arch=$(uname -m)
unpacker=$(pwd)
packages=$unpacker/bin
version=1.0.0-generic
#Dosya ad koruması
case $(ls sm-soft-unpacker-generic.sh) in
  sm-soft-unpacker-generic.sh)
  ;;
  *) 
    clear
    echo "You were warned not to change the file name!"
    exit ;;
esac;
case $1 in
  --version)
    echo $version; exit;
esac;
case $1 in
  --help)
    echo "Usage: ./sm-soft-unpacker-generic [flag]"
    echo "Wiew flags; ./sm-soft-unpacker-generic --flags"
    exit;
esac;
case $1 in
  --flags)
    echo "--help: Usage."
    echo "--flags: Wiew flags."
    echo "--dumprx: Stock ROM is extracted and makes it suitable for use with DumprX"
    echo "--dumprx-nd: Extracted software is not deleted when making it compatible with DumprX"
    exit;
esac;
#Ayıklama başlatılıyor
echo "Samsung Stock ROM unpacker by @YZBruh"
echo "######################################"
echo "*Scanning architecture..."
echo "*Device architecture: $arch"
echo "*Setting up packages..."
case $arch in
  armv7l)
    mkdir temp
    cd $packages
    chmod -R 777 *
    cd arm
    chmod 777 *
    cp $packages/arm/* $unpacker/temp
    cd $unpacker
  ;;
  aarch64)
    mkdir temp
    cd $packages
    chmod -R 777 *
    cd arm64
    chmod 777 *
    cp $packages/arm64/* $unpacker/temp
    cd $unpacker
  ;;
  x86_64)
    sudo mkdir temp
    cd $packages
    sudo chmod -R 777 *
    cd x86_64
    sudo chmod 777 *
    sudo cp $packages/x86_64/* $unpacker/temp
    cd $unpacker
  ;;
  i386)
    sudo mkdir temp
    cd $packages
    sudo chmod -R 777 *
    cd x86
    sudo chmod 777 *
    sudo cp $packages/x86/* $unpacker/temp
    cd $unpacker
esac;
#Stock ROM aranıyor...
echo "*Scanning firmware..."
firmware=$(ls *.zip)
if [ ! -f "$firmware" ]; then
echo "**Firmware not found!";
  rm -rf temp
  exit 1;
fi;
echo "*The ROM is moving..."
cd temp
mkdir firmware
mv $unpacker/$firmware $unpacker/temp/firmware
cd firmware
echo "*Extracting..."
extract_firmware=$(unzip *.zip)
if [ ! -f $extract_firmware ]; then
echo "**A bug occurred when firmware was extracted!";
  cd $unpacker
  rm -rf temp
  exit 1;
fi;
unset extract_firmware
rm -rf *.zip
echo "*AP is extracting..."
mkdir AP
mv *AP*.tar.md5 $unpacker/temp/firmware/AP
cp $unpacker/temp/tar $unpacker/temp/firmware/AP
cp $unpacker/temp/lz4 $unpacker/temp/firmware/AP
cd AP
extract_ap=$(./tar --extract --file *AP*.tar.md5)
if [ ! -f $extract_ap ]; then
echo "**A bug occurred when AP was extracted!";
  cd $unpacker
  rm -rf temp
  exit 1;
fi;
rm -rf tar
rm -rf *AP*.tar.md5
./lz4 --multiple --verbose --rm *.lz4
rm -rf lz4
chmod -R 777 *
unset extract_ap
cd $unpacker/temp/firmware
echo "*BL is extracting..."
mkdir BL
mv *BL*.tar.md5 $unpacker/temp/firmware/BL
cp $unpacker/temp/tar $unpacker/temp/firmware/BL
cp $unpacker/temp/lz4 $unpacker/temp/firmware/BL
cd BL
extract_bl=$(./tar --extract --file *BL*.tar.md5)
if [ ! -f $extract_bl ]; then
echo "**A bug occurred when BL was extracted!";
  cd $unpacker
  rm -rf temp
  exit 1;
fi;
rm -rf tar
rm -rf *BL*.tar.md5
./lz4 --multiple --verbose --rm *.lz4
rm -rf lz4
chmod -R 777 *
unset extract_bl
cd $unpacker/temp/firmware
echo "*CP is extracting..."
mkdir CP
mv *CP*.tar.md5 $unpacker/temp/firmware/CP
cp $unpacker/temp/tar $unpacker/temp/firmware/CP
cp $unpacker/temp/lz4 $unpacker/temp/firmware/CP
cd CP
extract_cp=$(./tar --extract --file *CP*.tar.md5)
if [ ! -f $extract_cp ]; then
echo "**A bug occurred when CP was extracted!";
  cd $unpacker
  rm -rf temp
  exit 1;
fi;
rm -rf tar
rm -rf *CP*.tar.md5
./lz4 --multiple --verbose --rm *.lz4
rm -rf lz4
chmod -R 777 *
unset extract_cp
cd $unpacker/temp/firmware
echo "*CSC is extracting..."
mkdir CSC
mv *CSC*.tar.md5 $unpacker/temp/firmware/CSC
cp $unpacker/temp/tar $unpacker/temp/firmware/CSC
cp $unpacker/temp/lz4 $unpacker/temp/firmware/CSC
cd CSC
extract_csc=$(./tar --extract --file *CSC*.tar.md5)
if [ ! -f $extract_csc ]; then
echo "**A bug occurred when CSC was extracted!";
  cd $unpacker
  rm -rf temp
  exit 1;
fi;
rm -rf tar
rm -rf *CSC*.tar.md5
./lz4 --multiple --verbose --rm *.lz4
rm -rf lz4
chmod -R 777 *
unset extract_csc
cd $unpacker/temp/firmware
echo "*Firmware extracted with success"
case $1 in
  --dumprx)
    echo "*Compliant with DumprX (files will be deleted)..."
    name=Unpacked-DumprX-Compatible-Firmware
    cp $unpacker/temp/zip $unpacker/temp/firmware
    ./zip $name *
    rm -rf zip
    cd $unpacker
    case $(readlink -e output) in
      $unpacker/output)
        rm -rf output;
        mkdir --mode=777 output;
      ;;
      *)
        mkdir --mode=777 output
    esac;
    cd $unpacker/temp/firmware
    mv $name.zip $unpacker/output
    rm -rf *
    cd $unpacker
    rm -rf temp
    unset name
    echo "*Successfull!"
    exit
esac;
case $1 in
  --dumprx-nd)
    echo "*Compliant with DumprX..."
    name=Unpacked-DumprX-Compatible-Firmware
    cp $unpacker/temp/zip $unpacker/temp/firmware
    ./zip $name *
    rm -rf zip
    cd $unpacker
    case $(readlink -e output) in
      $unpacker/output)
        rm -rf output;
        mkdir --mode=777 output;
      ;;
      *)
        mkdir --mode=777 output
    esac;
    cd $unpacker/temp/firmware
    mv $name.zip $unpacker/output
    mv AP $unpacker/output
    mv BL $unpacker/output
    mv CP $unpacker/output
    mv CSC $unpacker/output
    rm -rf *
    cd $unpacker
    rm -rf temp
    unset name
    echo "*Successfull!"
    exit
esac;
echo "*Extracted firmware is moving..."
cd $unpacker
case $(readlink -e output) in
  $unpacker/output)
  rm -rf output;
  mkdir --mode=777 output;
  ;;
  *)
  mkdir --mode=777 output
esac;
cd $unpacker/temp/firmware
mv AP $unpacker/output
mv BL $unpacker/output
mv CP $unpacker/output
mv CSC $unpacker/output
rm -rf *
cd $unpacker
rm -rf temp
echo "*Successfull!"
exit;